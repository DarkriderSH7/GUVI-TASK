var request = new XMLHttpRequest;
request.open('GET', 'https://restcountries.eu/rest/v2/all',true);
request.send();
request.onload = function(){
    var readData = JSON.parse(this.response);
    const sum=array.population((acc,currentval)=>{
        return accc+currentval
    })
    console.log(sum)
}