


///////////////////////////PROBLEM 0 A//////////////////////////////////
///////////////////////////////////////////////////////////////////////
// var cat = {
//   name: 'Fluffy',
//   activities: ['play', 'eat cat food'],
//   catFriends: [
//   {
//   name: 'bar',
//   activities: ['be grumpy', 'eat bread omblet'],
//   weight: 8,
//   furcolor: 'white'
//   },
//   {
//   name: 'foo',
//   activities: ['sleep', 'pre-sleep naps'],
//   weight: 3
//   }
//   ]
// }
//1
// cat.height = '80cm';
// cat.weight = '7kgs';
// cat[0] = 'Fluffyy';
//3
// console.log(cat.catFriends[0].activities)
// console.log(cat.catFriends[1].activities)
//4
// console.log(cat.catFriends[0].name)
// console.log(cat.catFriends[1].name)
//5
// var total=cat.catFriends[0].weight+cat.catFriends[1].weight
// console.log(total)

//6
//   count=0
// parseInt(count)
// for(var i in cat.catFriends)
//  {
//      count+=cat.catFriends[i].activities.length
//  }//end-here
//  count+=cat.activities.length
//  console.log(count)



// //7
// cat.catFriends[0].activities.push('purr','scratch')
// cat.catFriends[1].activities.push('play','nag')


// //8
// cat.catFriends[0].furcolor='black'




 //////////Question 0(b)///////////////////////////////////////////
//////////////////////////////////////////////////////////

// var myCar = {
//     make: 'Bugatti',
//     model: 'Bugatti La Voiture Noire',
//     year: 2019,
//     accidents: [
//     {
//     date: '3/15/2019',
//     damage_points: 5000,
//     atFaultForAccident: true
//     },
//     {
//     date: '7/4/2022',
//     damage_points: 2200,
//     atFaultForAccident: true
//     },
//     {
//     date: '6/22/2021',
//     damage_points: 7900,
//     atFaultForAccident: true
//     }
//     ]
//    }
   
   
   
   
   //1
   // for(var i in myCar.accidents){
   //     myCar.accidents[i].atFaultForAccident=false
   // }
   //  console.log(myCar.accidents[1].atFaultForAccident)
   
   
   
   
   //2
   // for(var i in myCar.accidents){
   //     console.log(myCar.accidents[i].date)
   // }
   
   // Question 1/////////////
// var obj = {name :'RajiniKanth', age : 33, hasPets : false};

// function printAllValues(obj) {
//  newArray=[];
// newArray=Object.values(obj);
//   console.log(newArray)
//   ;
// }
// printAllValues(obj)



// Question 2
// var obj = {name :'RajiniKanth', age : 33, hasPets : false};

//  function printAllValues(obj) {
//   newArray=[];
// newArray=Object.keys(obj);
// console.log(newArray)
//   ;
// }
//  printAllValues(obj)


//Question 3
// var obj = {name: “ISRO”, age: 35, role: “Scientist”};

// function convertListToObject(obj) {
//  newArray=[];
// newArray=Object.entries(obj);
// console.log(newArray);
// }
// convertListToObject(obj)
   





// // Question 4
// var arr = ['GUVI', 'I', 'am', 'Geek'];
// function transformFirstAndLast(arr) {

//   var myObject = {};
//   myObject[arr[0]] = arr[arr.length-1];
//   return myObject;
// }
// console.log(transformFirstAndLast(arr))





// //QUESTION 5
// var array = [['make', 'Ford'], ['model', 'Mustang'], ['year', 1964]];

// function fromListToObject(arr) {

//  var obj = {};
 
//  var collection = arr;
//  for(var i = 0; i < arr.length; i++){
//   var dataArray =collection[i];
//   for(var j= 0; j < collection[i].length; j++){
//      obj[dataArray[0]] = dataArray[1]
//   }
//  }
//  return obj;
// }
// console.log(fromListToObject(array));
//  });


//QUESTION 6///////////
//////////////////////////


// var arr= [[['firstName', 'Vasanth'], ['lastName', 'Raja'], ['age', 24], ['role', 'JSWizard']], [['firstName', 'Sri'], ['lastName', 'Devi'], ['age', 28], ['role', 'Coder']]];

// function transformEmployeeData(array) {

//     var collection = [];
//     for(var i = 0; i < array.length; i++){
//       var obj = {};
//       var dataArray =array[i];
//       for(var j= 0; j < array[i].length; j++){
//         obj[dataArray[j][0]] = dataArray[j][1]
           
//       }
//       collection.push(obj);
//     }
//     return collection;
  //transformEmployeeData(array)
//   }

/////////////QUESTION 7/////////
//////////////////////////
// var expected = {foo: 5, bar: 6};
// var expected1 = {foo: 6, bar: 5};
// var actual = {foo: 5, bar: 6};

// function assertObjectsEqual(actual, expected, testName){
//   actualStr = JSON.stringify(actual)
//   expectedStr = JSON.stringify(expected)
//   if(actualStr == expectedStr){
//     return "Passed"
//   } else{
//     return "FAILED ["+testName+"] Expected "+actualStr+", but got "+expectedStr
//   }
// }

// console.log(assertObjectsEqual(actual, expected, 'test1'))
// console.log(assertObjectsEqual(actual, expected1, 'test2'))
//QUESTION 8

// var securityQuestions = [
//     {
//       question: 'What was your first pet’s name?',
//       expectedAnswer: 'FlufferNutter'
//     },
//     {
//       question: 'What was the model year of your first car?',
//       expectedAnswer: '1985'
//     },
//     {
//       question: 'What city were you born in?',
//       expectedAnswer: 'NYC'
//     }
//   ];

//   function chksecurityQuestions(securityQuestions,question, answer) { 
//     for (var i = 0; i < securityQuestions.length; i++)
//     {
//       for (keys in securityQuestions[i]){
//         if(keys == "question"){
//           if(securityQuestions[i].question == question && securityQuestions[i].expectedAnswer == answer){
//               return true;
//           }
//         }
//       }
//     }

//   return false; 

//   }

//  QUESTION 9
//   var ques = 'What was your first pet’s name?';
//   var ans  =  'FlufferNutter';
  
//   var status = chksecurityQuestions(securityQuestions, ques, ans);
//   console.log(status); // true
  
// 
//   var ques = 'What was your first pet’s name?';
//   var ans  =  'DufferNutter';
  
//   var status = chksecurityQuestions(securityQuestions, ques, ans);
//   console.log(status); // false
    //Q 10
// var students = [
//     {
//       name: 'Siddharth Abhimanyu', 
//       age: 21
//     }, 
//     { 
//       name: 'Malar', 
//       age: 25
//     },
//     {
//       name: 'Maari',
//       age: 18
//     },
//     {
//       name: 'Bhallala Deva',
//       age: 17
//     },
//     {
//       name: 'Baahubali',
//       age: 16
//     },
//     {
//         name: 'AAK chandran',
//         age: 23
//     },
//     {
//       name:'Gabbar Singh',
//       age: 33
//     },
//     {
//       name: 'Mogambo',
//       age: 53
//     },
//     {
//       name: 'Munnabhai',
//       age: 40
//     },
//     {
//       name: 'Sher Khan',
//       age: 20
//     },
//     {
//       name: 'Chulbul Pandey'
//       ,age: 19
//     },
//     {
//       name: 'Anthony',
//       age: 28
//     },
//     {
//       name: 'Devdas',
//       age: 56
//     } 
//   ];
//   function returnMinors(arr)
//   {
//     var newObj = [];
//     for (var i = 0; i< arr.length; i++){
//       if (arr[i].age < 20){
//         newObj.push(arr[i]);
//       }
//     }
//     return newObj;
//   }
//   console.log(returnMinors(students));
                  
});